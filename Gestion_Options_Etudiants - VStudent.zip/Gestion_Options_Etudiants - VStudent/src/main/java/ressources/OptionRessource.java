package ressources;


import entities.Option;
import metiers.OptionBusiness;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.Optional;


@Path("/options")
public class OptionRessource {
    OptionBusiness optionBusiness = new OptionBusiness();
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Option> getAll(){
        return  this.optionBusiness.getListeOptions();
    }
    @GET
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    @Path("/{code}")
    public Response getByCode(@PathParam("code") int code){
        Option option = this.optionBusiness.getOptionByCode(code);
        if(option == null){
            return Response.status(Response.Status.NOT_FOUND).build(); // modifié : 404 si l'option n'existe pas
        }
        return Response.status(Response.Status.OK).entity(this.optionBusiness.getOptionByCode(code)).build();
    }
    @GET
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    @Path("/semestre/{semestre}") // modifié : chemin différent pour éviter le conflit avec "/{code}"
    public Response getBySemestre(@PathParam("semestre") int semestre) {
        return Response.status(Response.Status.OK)
                .entity(this.optionBusiness.getOptionsBySemestre(semestre))
                .build();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response addOption(Option option) {
        if (!optionBusiness.addOption(option)) { // modifié : "!" ajouté, on renvoie une erreur seulement si l'ajout échoue
            return Response.status(Response.Status.BAD_REQUEST) // modifié : 400 au lieu de 404
                    .build();
        }

        return Response.status(Response.Status.CREATED)
                .entity("added with success")
                .build();
    }
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_JSON})
    @Path("/{code}")
    public Response updateOption(Option option,@PathParam("code")int code){
        if (optionBusiness.updateOption(code,option)){
            return Response.status(Response.Status.OK).entity(this.optionBusiness.getOptionByCode(code)).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
    @DELETE
    @Path("/{code}")
    public  Response deleteOption(@PathParam("code")int code){
        if (optionBusiness.deleteOption(code)){
            return Response.status(Response.Status.OK).entity(this.optionBusiness.deleteOption(code)).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
}